package _02Shapes;

public class Main {
}
